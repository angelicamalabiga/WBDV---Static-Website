//show navbar

const nav = document.querySelector('.navbar');
const toggle = document.querySelector('.icons');
toggle.onclick = function() {
    nav.classList.toggle('show-nav')
}
